<?php
$this->conn = @mysql_connect($dbhost, $dbuser, $dbpassword, true);
?>