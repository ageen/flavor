;<?php return; ?>
[SQL]
host = localhost
port = 3306
user = liuxin
password = liuxin@mysql
dbname = quanfeng