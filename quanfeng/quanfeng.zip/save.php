<?php
require_once("global.php");
foreach($_POST as $k=>$v){
	if($v == ""){
		echo "empty";
		exit;
	} else {
		$feed[$k] = nl2br(htmlspecialchars($v));
	}
}
$time = date("Y-m-d H:i:s");
$db = new Db();
$db->bind("nickname",$feed["send_user"]);
$db->bind("content",$feed["message_content"]);
$db->bind("date_time",$time);
$insert	= $db->query("INSERT INTO q_message(nickname,content,date_time)VALUES(:nickname,:content,:date_time)");
if($insert){
	echo "success";
	exit;
} else {
	echo "fail";
	exit;
}
?>